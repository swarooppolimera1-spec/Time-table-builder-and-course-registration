package project2;
import java.util.Scanner;

public class SearchServiceModule {

	    void searchStudent(
	            Scanner sc,
	            StudentModule student) {

	        if (!student.stored) {
	            System.out.println("No student stored.");
	            return;
	        }

	        System.out.println("\n--- Search Student ---");

	        System.out.print("Enter Student ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == student.studentId)
	            student.displayStudent();
	        else
	            System.out.println("Student not found.");
	    }

	    void searchCourse(
	            Scanner sc,
	            CourseModule course) {

	        if (!course.stored) {
	            System.out.println("No course stored.");
	            return;
	        }

	        System.out.println("\n--- Search Course ---");

	        System.out.print("Enter Course ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == course.courseId)
	            course.displayCourse();
	        else
	            System.out.println("Course not found.");
	    }

	    void searchFaculty(
	            Scanner sc,
	            FacultyModule faculty) {

	        if (!faculty.stored) {
	            System.out.println("No faculty stored.");
	            return;
	        }

	        System.out.println("\n--- Search Faculty ---");

	        System.out.print("Enter Faculty ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == faculty.facultyId)
	            faculty.displayFaculty();
	        else
	            System.out.println("Faculty not found.");
	    }

	    void searchRegistration(
	            Scanner sc,
	            RegistrationModule registration) {

	        if (!registration.stored) {
	            System.out.println("No registration stored.");
	            return;
	        }

	        System.out.println("\n--- Search Registration ---");

	        System.out.print("Enter Registration ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == registration.registrationId)
	            registration.displayRegistration();
	        else
	            System.out.println("Registration not found.");
	    }
	}


