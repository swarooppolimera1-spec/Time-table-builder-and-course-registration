package project2;
import java.util.Scanner;
public class Main {

	    public static void main(String[] args) {

	        Scanner sc = new Scanner(System.in);

	        StudentModule student =
	                new StudentModule();

	        CourseModule course =
	                new CourseModule();

	        FacultyModule faculty =
	                new FacultyModule();

	        TimetableModule timetable =
	                new TimetableModule();

	        RegistrationModule registration =
	                new RegistrationModule();

	        ValidateServiceModule validate =
	                new ValidateServiceModule();

	        SearchServiceModule search =
	                new SearchServiceModule();

	        ReportGenerationServiceModule report =
	                new ReportGenerationServiceModule();

	        AnalysisServiceModule analysis =
	                new AnalysisServiceModule();

	        int choice;

	        do {

	            System.out.println("\n=================================");
	            System.out.println("        TIMETABLEX PROJECT");
	            System.out.println("=================================");

	            System.out.println("1. Student Module");
	            System.out.println("2. Course Module");
	            System.out.println("3. Faculty Module");
	            System.out.println("4. Timetable Module");
	            System.out.println("5. Registration Module");
	            System.out.println("6. Validate Service Module");
	            System.out.println("7. Search Service Module");
	            System.out.println("8. Report Generation Service Module");
	            System.out.println("9. Analysis Service Module");
	            System.out.println("10. Exit");

	            System.out.println("=================================");

	            System.out.print("Enter Choice: ");
	            choice = sc.nextInt();
	            sc.nextLine();

	            switch (choice) {

	                // ================= STUDENT =================

	                case 1:

	                    int studentChoice;

	                    do {

	                        System.out.println("\n--- STUDENT MODULE ---");

	                        System.out.println("1. Register Student");
	                        System.out.println("2. Update Student");
	                        System.out.println("3. Display Student");
	                        System.out.println("4. Back");

	                        System.out.print("Enter Choice: ");
	                        studentChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (studentChoice) {

	                            case 1:
	                                student.registerStudent(sc);
	                                break;

	                            case 2:
	                                student.updateStudent(sc);
	                                break;

	                            case 3:
	                                student.displayStudent();
	                                break;

	                            case 4:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (studentChoice != 4);

	                    break;


	                // ================= COURSE =================

	                case 2:

	                    int courseChoice;

	                    do {

	                        System.out.println("\n--- COURSE MODULE ---");

	                        System.out.println("1. Add Course");
	                        System.out.println("2. Update Course");
	                        System.out.println("3. Display Course");
	                        System.out.println("4. Back");

	                        System.out.print("Enter Choice: ");
	                        courseChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (courseChoice) {

	                            case 1:
	                                course.addCourse(sc);
	                                break;

	                            case 2:
	                                course.updateCourse(sc);
	                                break;

	                            case 3:
	                                course.displayCourse();
	                                break;

	                            case 4:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (courseChoice != 4);

	                    break;


	                // ================= FACULTY =================

	                case 3:

	                    int facultyChoice;

	                    do {

	                        System.out.println("\n--- FACULTY MODULE ---");

	                        System.out.println("1. Add Faculty");
	                        System.out.println("2. Assign Course");
	                        System.out.println("3. Display Faculty");
	                        System.out.println("4. Back");

	                        System.out.print("Enter Choice: ");
	                        facultyChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (facultyChoice) {

	                            case 1:
	                                faculty.addFaculty(sc);
	                                break;

	                            case 2:
	                                faculty.assignCourse(sc, course);
	                                break;

	                            case 3:
	                                faculty.displayFaculty();
	                                break;

	                            case 4:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (facultyChoice != 4);

	                    break;


	                // ================= TIMETABLE =================

	                case 4:

	                    int timetableChoice;

	                    do {

	                        System.out.println("\n--- TIMETABLE MODULE ---");

	                        System.out.println("1. Generate Timetable");
	                        System.out.println("2. Update Schedule");
	                        System.out.println("3. Display Timetable");
	                        System.out.println("4. Allocate Classroom");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        timetableChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (timetableChoice) {

	                            case 1:
	                                timetable.generateTimetable(
	                                        sc, course);
	                                break;

	                            case 2:
	                                timetable.updateSchedule(sc);
	                                break;

	                            case 3:
	                                timetable.displayTimetable();
	                                break;

	                            case 4:
	                                timetable.allocateClassroom(sc);
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (timetableChoice != 5);

	                    break;


	                // ================= REGISTRATION =================

	                case 5:

	                    int registrationChoice;

	                    do {

	                        System.out.println("\n--- REGISTRATION MODULE ---");

	                        System.out.println("1. Register Course");
	                        System.out.println("2. Drop Course");
	                        System.out.println("3. Display Registration");
	                        System.out.println("4. Calculate Credits");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        registrationChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (registrationChoice) {

	                            case 1:
	                                registration.registerCourse(
	                                        sc,
	                                        student,
	                                        course);
	                                break;

	                            case 2:
	                                registration.dropCourse();
	                                break;

	                            case 3:
	                                registration.displayRegistration();
	                                break;

	                            case 4:
	                                registration.calculateCredits();
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (registrationChoice != 5);

	                    break;


	                // ================= VALIDATE =================

	                case 6:

	                    int validateChoice;

	                    do {

	                        System.out.println("\n--- VALIDATE SERVICE MODULE ---");

	                        System.out.println("1. Validate Student ID");
	                        System.out.println("2. Validate Course ID");
	                        System.out.println("3. Validate Semester");
	                        System.out.println("4. Validate Credits");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        validateChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (validateChoice) {

	                            case 1:
	                                validate.validateStudentId(
	                                        sc, student);
	                                break;

	                            case 2:
	                                validate.validateCourseId(
	                                        sc, course);
	                                break;

	                            case 3:
	                                validate.validateSemester(
	                                        sc, student);
	                                break;

	                            case 4:
	                                validate.validateCredits(
	                                        sc, course);
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (validateChoice != 5);

	                    break;


	                // ================= SEARCH =================

	                case 7:

	                    int searchChoice;

	                    do {

	                        System.out.println("\n--- SEARCH SERVICE MODULE ---");

	                        System.out.println("1. Search Student");
	                        System.out.println("2. Search Course");
	                        System.out.println("3. Search Faculty");
	                        System.out.println("4. Search Registration");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        searchChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (searchChoice) {

	                            case 1:
	                                search.searchStudent(
	                                        sc, student);
	                                break;

	                            case 2:
	                                search.searchCourse(
	                                        sc, course);
	                                break;

	                            case 3:
	                                search.searchFaculty(
	                                        sc, faculty);
	                                break;

	                            case 4:
	                                search.searchRegistration(
	                                        sc, registration);
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (searchChoice != 5);

	                    break;


	                // ================= REPORT =================

	                case 8:

	                    int reportChoice;

	                    do {

	                        System.out.println("\n--- REPORT GENERATION SERVICE MODULE ---");

	                        System.out.println("1. Student Report");
	                        System.out.println("2. Course Report");
	                        System.out.println("3. Timetable Report");
	                        System.out.println("4. Registration Report");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        reportChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (reportChoice) {

	                            case 1:
	                                report.generateStudentReport(
	                                        student);
	                                break;

	                            case 2:
	                                report.generateCourseReport(
	                                        course);
	                                break;

	                            case 3:
	                                report.generateTimetableReport(
	                                        timetable);
	                                break;

	                            case 4:
	                                report.generateRegistrationReport(
	                                        registration);
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (reportChoice != 5);

	                    break;


	                // ================= ANALYSIS =================

	                case 9:

	                    int analysisChoice;

	                    do {

	                        System.out.println("\n--- ANALYSIS SERVICE MODULE ---");

	                        System.out.println("1. Department Wise Registration");
	                        System.out.println("2. Most Popular Course");
	                        System.out.println("3. Calculate Average Credits");
	                        System.out.println("4. Generate Summary");
	                        System.out.println("5. Back");

	                        System.out.print("Enter Choice: ");
	                        analysisChoice = sc.nextInt();
	                        sc.nextLine();

	                        switch (analysisChoice) {

	                            case 1:
	                                analysis.departmentWiseRegistration(
	                                        student,
	                                        registration);
	                                break;

	                            case 2:
	                                analysis.mostPopularCourse(
	                                        course,
	                                        registration);
	                                break;

	                            case 3:
	                                analysis.calculateAverageCredits(
	                                        registration);
	                                break;

	                            case 4:
	                                analysis.generateSummary(
	                                        student,
	                                        course,
	                                        faculty,
	                                        timetable,
	                                        registration);
	                                break;

	                            case 5:
	                                System.out.println("Back to Main Menu.");
	                                break;

	                            default:
	                                System.out.println("Invalid Choice.");
	                        }

	                    } while (analysisChoice != 5);

	                    break;


	                // ================= EXIT =================

	                case 10:

	                    System.out.println("\n=================================");
	                    System.out.println("Thank you for using TIMETABLEX!");
	                    System.out.println("Program exited successfully.");
	                    System.out.println("=================================");

	                    break;


	                default:

	                    System.out.println(
	                            "Invalid Choice. Please enter 1 to 10.");
	            }

	        } while (choice != 10);

	        sc.close();
	    }
	}

