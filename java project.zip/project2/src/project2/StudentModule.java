package project2;
import java.util.Scanner;
public class StudentModule {
	    int studentId;
	    String studentName;
	    String department;
	    int semester;

	    boolean stored = false;

	    void registerStudent(Scanner sc) {

	        System.out.println("\n--- Register Student ---");

	        System.out.print("Enter Student ID: ");
	        studentId = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Student Name: ");
	        studentName = sc.nextLine();

	        System.out.print("Enter Department: ");
	        department = sc.nextLine();

	        System.out.print("Enter Semester: ");
	        semester = sc.nextInt();
	        sc.nextLine();

	        stored = true;

	        System.out.println("Student stored successfully.");
	    }

	    void updateStudent(Scanner sc) {

	        if (!stored) {
	            System.out.println("No student stored. Register student first.");
	            return;
	        }

	        System.out.println("\n--- Update Student ---");

	        System.out.print("Enter Student Name: ");
	        studentName = sc.nextLine();

	        System.out.print("Enter Department: ");
	        department = sc.nextLine();

	        System.out.print("Enter Semester: ");
	        semester = sc.nextInt();
	        sc.nextLine();

	        System.out.println("Student updated successfully.");
	    }

	    void displayStudent() {

	        if (!stored) {
	            System.out.println("No student data available.");
	            return;
	        }

	        System.out.println("\n--- Student Details ---");

	        System.out.println("Student ID : " + studentId);
	        System.out.println("Name       : " + studentName);
	        System.out.println("Department : " + department);
	        System.out.println("Semester   : " + semester);
	    }
	}