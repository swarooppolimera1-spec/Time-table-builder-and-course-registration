package project2;

public class ReportGenerationServiceModule {
	

	    String reportTitle;

	    void generateStudentReport(StudentModule student) {

	        if (!student.stored) {
	            System.out.println("No student data available.");
	            return;
	        }

	        reportTitle = "STUDENT REPORT";

	        System.out.println("\n========== " + reportTitle + " ==========");

	        student.displayStudent();
	    }

	    void generateCourseReport(CourseModule course) {

	        if (!course.stored) {
	            System.out.println("No course data available.");
	            return;
	        }

	        reportTitle = "COURSE REPORT";

	        System.out.println("\n========== " + reportTitle + " ==========");

	        course.displayCourse();
	    }

	    void generateTimetableReport(TimetableModule timetable) {

	        if (!timetable.stored) {
	            System.out.println("No timetable data available.");
	            return;
	        }

	        reportTitle = "TIMETABLE REPORT";

	        System.out.println("\n========== " + reportTitle + " ==========");

	        timetable.displayTimetable();
	    }

	    void generateRegistrationReport(
	            RegistrationModule registration) {

	        if (!registration.stored) {
	            System.out.println("No registration data available.");
	            return;
	        }

	        reportTitle = "REGISTRATION REPORT";

	        System.out.println("\n========== " + reportTitle + " ==========");

	        registration.displayRegistration();
	    }
	}

