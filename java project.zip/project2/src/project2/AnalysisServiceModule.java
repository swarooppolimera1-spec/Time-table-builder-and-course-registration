package project2;

public class AnalysisServiceModule {


	    void departmentWiseRegistration(
	            StudentModule student,
	            RegistrationModule registration) {

	        System.out.println("\n--- Department Wise Registration ---");

	        if (!student.stored) {
	            System.out.println("No student data available.");
	            return;
	        }

	        if (!registration.stored) {
	            System.out.println("No registration data available.");
	            return;
	        }

	        if (student.studentId == registration.studentId &&
	            registration.status.equals("Registered")) {

	            System.out.println(
	                    "Department: " + student.department);

	            System.out.println(
	                    "Registrations: 1");

	        } else {
	            System.out.println("No active registration found.");
	        }
	    }

	    void mostPopularCourse(
	            CourseModule course,
	            RegistrationModule registration) {

	        System.out.println("\n--- Most Popular Course ---");

	        if (!course.stored) {
	            System.out.println("No course data available.");
	            return;
	        }

	        if (!registration.stored) {
	            System.out.println("No registration data available.");
	            return;
	        }

	        if (course.courseId == registration.courseId &&
	            registration.status.equals("Registered")) {

	            System.out.println(
	                    "Course ID: " + course.courseId);

	            System.out.println(
	                    "Course Name: " + course.courseName);

	            System.out.println(
	                    "Registrations: 1");

	        } else {
	            System.out.println("No active registration found.");
	        }
	    }

	    void calculateAverageCredits(
	            RegistrationModule registration) {

	        System.out.println("\n--- Average Credits ---");

	        if (!registration.stored) {
	            System.out.println("No registration data available.");
	            return;
	        }

	        if (registration.status.equals("Registered")) {

	            double average = registration.credits;

	            System.out.println(
	                    "Average Credits: " + average);

	        } else {
	            System.out.println("No active registration.");
	        }
	    }

	    void generateSummary(
	            StudentModule student,
	            CourseModule course,
	            FacultyModule faculty,
	            TimetableModule timetable,
	            RegistrationModule registration) {

	        System.out.println("\n========== ACADEMIC SUMMARY ==========");

	        if (student.stored)
	            System.out.println(
	                    "Student Name : " + student.studentName);
	        else
	            System.out.println("Student Name : Not Available");

	        if (course.stored)
	            System.out.println(
	                    "Course Name  : " + course.courseName);
	        else
	            System.out.println("Course Name  : Not Available");

	        if (faculty.stored)
	            System.out.println(
	                    "Faculty Name : " + faculty.facultyName);
	        else
	            System.out.println("Faculty Name : Not Available");

	        if (timetable.stored) {
	            System.out.println(
	                    "Classroom    : " + timetable.classroom);

	            System.out.println(
	                    "Time Slot    : " + timetable.timeSlot);
	        }

	        if (registration.stored) {

	            System.out.println(
	                    "Registration : " + registration.status);

	            System.out.println(
	                    "Credits      : " + registration.credits);

	        } else {
	            System.out.println("Registration : Not Available");
	        }

	        System.out.println("=======================================");
	    }
	}

