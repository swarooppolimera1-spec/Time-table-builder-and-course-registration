package project2;
import java.util.Scanner;
public class TimetableModule {
	    int timetableId;
	    int courseId;
	    String classroom;
	    String timeSlot;

	    boolean stored = false;

	    void generateTimetable(Scanner sc, CourseModule course) {

	        if (!course.stored) {
	            System.out.println("No course stored. Add course first.");
	            return;
	        }

	        System.out.println("\n--- Generate Timetable ---");

	        System.out.print("Enter Timetable ID: ");
	        timetableId = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Course ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id != course.courseId) {
	            System.out.println("Course ID does not match stored course.");
	            return;
	        }

	        courseId = id;

	        System.out.print("Enter Classroom: ");
	        classroom = sc.nextLine();

	        System.out.print("Enter Time Slot: ");
	        timeSlot = sc.nextLine();

	        stored = true;

	        System.out.println("Timetable stored successfully.");
	    }

	    void updateSchedule(Scanner sc) {

	        if (!stored) {
	            System.out.println("No timetable stored. Generate timetable first.");
	            return;
	        }

	        System.out.println("\n--- Update Schedule ---");

	        System.out.print("Enter Classroom: ");
	        classroom = sc.nextLine();

	        System.out.print("Enter Time Slot: ");
	        timeSlot = sc.nextLine();

	        System.out.println("Schedule updated successfully.");
	    }

	    void displayTimetable() {

	        if (!stored) {
	            System.out.println("No timetable data available.");
	            return;
	        }

	        System.out.println("\n--- Timetable Details ---");

	        System.out.println("Timetable ID : " + timetableId);
	        System.out.println("Course ID    : " + courseId);
	        System.out.println("Classroom    : " + classroom);
	        System.out.println("Time Slot    : " + timeSlot);
	    }

	    void allocateClassroom(Scanner sc) {

	        if (!stored) {
	            System.out.println("No timetable stored. Generate timetable first.");
	            return;
	        }

	        System.out.println("\n--- Allocate Classroom ---");

	        System.out.print("Enter Classroom: ");
	        classroom = sc.nextLine();

	        System.out.println("Classroom allocated successfully.");
	    }
	}

