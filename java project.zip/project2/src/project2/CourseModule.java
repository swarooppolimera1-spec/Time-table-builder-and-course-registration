package project2;
import java.util.Scanner;

public class CourseModule {
	    int courseId;
	    String courseName;
	    int credits;
	    int facultyId;

	    boolean stored = false;

	    void addCourse(Scanner sc) {

	        System.out.println("\n--- Add Course ---");

	        System.out.print("Enter Course ID: ");
	        courseId = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Course Name: ");
	        courseName = sc.nextLine();

	        System.out.print("Enter Credits: ");
	        credits = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Faculty ID: ");
	        facultyId = sc.nextInt();
	        sc.nextLine();

	        stored = true;

	        System.out.println("Course stored successfully.");
	    }

	    void updateCourse(Scanner sc) {

	        if (!stored) {
	            System.out.println("No course stored. Add course first.");
	            return;
	        }

	        System.out.println("\n--- Update Course ---");

	        System.out.print("Enter Course Name: ");
	        courseName = sc.nextLine();

	        System.out.print("Enter Credits: ");
	        credits = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Faculty ID: ");
	        facultyId = sc.nextInt();
	        sc.nextLine();

	        System.out.println("Course updated successfully.");
	    }

	    void displayCourse() {

	        if (!stored) {
	            System.out.println("No course data available.");
	            return;
	        }

	        System.out.println("\n--- Course Details ---");

	        System.out.println("Course ID   : " + courseId);
	        System.out.println("Course Name : " + courseName);
	        System.out.println("Credits     : " + credits);
	        System.out.println("Faculty ID  : " + facultyId);
	    }
	}

