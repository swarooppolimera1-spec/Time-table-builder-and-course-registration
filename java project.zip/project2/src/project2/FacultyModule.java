package project2;
import java.util.Scanner;
public class FacultyModule {
	    int facultyId;
	    String facultyName;
	    String specialization;
	    String designation;

	    int assignedCourseId;

	    boolean stored = false;

	    void addFaculty(Scanner sc) {

	        System.out.println("\n--- Add Faculty ---");

	        System.out.print("Enter Faculty ID: ");
	        facultyId = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Faculty Name: ");
	        facultyName = sc.nextLine();

	        System.out.print("Enter Specialization: ");
	        specialization = sc.nextLine();

	        System.out.print("Enter Designation: ");
	        designation = sc.nextLine();

	        assignedCourseId = 0;

	        stored = true;

	        System.out.println("Faculty stored successfully.");
	    }

	    void assignCourse(Scanner sc, CourseModule course) {

	        if (!stored) {
	            System.out.println("No faculty stored. Add faculty first.");
	            return;
	        }

	        if (!course.stored) {
	            System.out.println("No course stored. Add course first.");
	            return;
	        }

	        System.out.println("\n--- Assign Course ---");

	        System.out.print("Enter Course ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == course.courseId &&
	            facultyId == course.facultyId) {

	            assignedCourseId = id;

	            System.out.println("Course assigned successfully.");

	        } else {
	            System.out.println("Course ID or Faculty ID does not match.");
	        }
	    }

	    void displayFaculty() {

	        if (!stored) {
	            System.out.println("No faculty data available.");
	            return;
	        }

	        System.out.println("\n--- Faculty Details ---");

	        System.out.println("Faculty ID      : " + facultyId);
	        System.out.println("Faculty Name    : " + facultyName);
	        System.out.println("Specialization  : " + specialization);
	        System.out.println("Designation     : " + designation);

	        if (assignedCourseId != 0)
	            System.out.println("Assigned Course : " + assignedCourseId);
	        else
	            System.out.println("Assigned Course : Not Assigned");
	    }
	}

