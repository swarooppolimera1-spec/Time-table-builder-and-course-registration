package project2;
import java.util.Scanner;
public class ValidateServiceModule {

	    void validateStudentId(
	            Scanner sc,
	            StudentModule student) {

	        if (!student.stored) {
	            System.out.println("No student stored.");
	            return;
	        }

	        System.out.print("Enter Student ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == student.studentId)
	            System.out.println("Valid Student ID.");
	        else
	            System.out.println("Invalid Student ID.");
	    }

	    void validateCourseId(
	            Scanner sc,
	            CourseModule course) {

	        if (!course.stored) {
	            System.out.println("No course stored.");
	            return;
	        }

	        System.out.print("Enter Course ID: ");
	        int id = sc.nextInt();
	        sc.nextLine();

	        if (id == course.courseId)
	            System.out.println("Valid Course ID.");
	        else
	            System.out.println("Invalid Course ID.");
	    }

	    void validateSemester(
	            Scanner sc,
	            StudentModule student) {

	        if (!student.stored) {
	            System.out.println("No student stored.");
	            return;
	        }

	        System.out.print("Enter Semester: ");
	        int semester = sc.nextInt();
	        sc.nextLine();

	        if (semester == student.semester)
	            System.out.println("Valid Semester.");
	        else
	            System.out.println("Invalid Semester.");
	    }

	    void validateCredits(
	            Scanner sc,
	            CourseModule course) {

	        if (!course.stored) {
	            System.out.println("No course stored.");
	            return;
	        }

	        System.out.print("Enter Credits: ");
	        int credits = sc.nextInt();
	        sc.nextLine();

	        if (credits == course.credits)
	            System.out.println("Valid Credits.");
	        else
	            System.out.println("Invalid Credits.");
	    }
	}

