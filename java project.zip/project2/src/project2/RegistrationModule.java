package project2;
import java.util.Scanner;
public class RegistrationModule {
	    int registrationId;
	    int studentId;
	    int courseId;
	    String registrationDate;
	    String status;
	    int credits;

	    boolean stored = false;

	    void registerCourse(
	            Scanner sc,
	            StudentModule student,
	            CourseModule course) {

	        if (!student.stored) {
	            System.out.println("No student stored. Register student first.");
	            return;
	        }

	        if (!course.stored) {
	            System.out.println("No course stored. Add course first.");
	            return;
	        }

	        System.out.println("\n--- Register Course ---");

	        System.out.print("Enter Registration ID: ");
	        registrationId = sc.nextInt();
	        sc.nextLine();

	        System.out.print("Enter Student ID: ");
	        int sid = sc.nextInt();
	        sc.nextLine();

	        if (sid != student.studentId) {
	            System.out.println("Student ID does not match stored student.");
	            return;
	        }

	        System.out.print("Enter Course ID: ");
	        int cid = sc.nextInt();
	        sc.nextLine();

	        if (cid != course.courseId) {
	            System.out.println("Course ID does not match stored course.");
	            return;
	        }

	        studentId = sid;
	        courseId = cid;

	        System.out.print("Enter Registration Date: ");
	        registrationDate = sc.nextLine();

	        credits = course.credits;

	        status = "Registered";

	        stored = true;

	        System.out.println("Course registered successfully.");
	    }

	    void dropCourse() {

	        if (!stored) {
	            System.out.println("No registration available.");
	            return;
	        }

	        status = "Dropped";

	        System.out.println("Course dropped successfully.");
	    }

	    void displayRegistration() {

	        if (!stored) {
	            System.out.println("No registration data available.");
	            return;
	        }

	        System.out.println("\n--- Registration Details ---");

	        System.out.println("Registration ID   : " + registrationId);
	        System.out.println("Student ID        : " + studentId);
	        System.out.println("Course ID         : " + courseId);
	        System.out.println("Registration Date : " + registrationDate);
	        System.out.println("Status            : " + status);
	        System.out.println("Credits           : " + credits);
	    }

	    void calculateCredits() {

	        if (!stored) {
	            System.out.println("No registration available.");
	            return;
	        }

	        System.out.println("\n--- Credit Details ---");
	        System.out.println("Registered Credits: " + credits);
	    }
	}

